import { Injectable } from '@nestjs/common';
import { ReportFormat, ReportOptions } from '../types/report.types';
import { generateExcelReport } from '../utils/excel.utils';
import { generateCsvReport } from '../utils/csv.utils';
import { generatePdfReport } from '../utils/pdf.utils';

@Injectable()
export class ReportService {
  async generateReport(options: ReportOptions): Promise<Buffer> {
    switch (options.format) {
      case ReportFormat.EXCEL:
        return generateExcelReport(options);
      case ReportFormat.CSV:
        return generateCsvReport(options);
      case ReportFormat.PDF:
        return generatePdfReport(options);
      default:
        throw new Error('Unsupported format');
    }
  }
}



import { ReportStyleProfiles } from '../styles/style-profiles';

...

for (const sheetConfig of options.sheets) {
  const profile = sheetConfig.styleProfileKey
    ? ReportStyleProfiles[sheetConfig.styleProfileKey]
    : undefined;

  const sheet = workbook.addWorksheet(sheetConfig.sheetName || 'Sheet');
  sheet.columns = sheetConfig.columns.map(col => ({
    header: col.header,
    key: col.key,
    width: col.width || 20,
  }));

  // Apply header style from profile
  sheet.getRow(1).eachCell((cell, colNum) => {
    const col = sheetConfig.columns[colNum - 1];
    const profileStyle = profile?.headerStyle;
    if (col?.headerStyle) {
      cell.style = col.headerStyle;
    } else if (profileStyle) {
      cell.style = profileStyle;
    }
  });

  sheetConfig.data.forEach((rowData, rowIndex) => {
    const row = sheet.addRow(rowData);

    const rowStyle =
      sheetConfig.getRowStyle?.(rowData, rowIndex) || profile?.rowStyle;
    if (rowStyle) {
      row.eachCell(cell => {
        cell.style = { ...cell.style, ...rowStyle };
      });
    }

    sheetConfig.columns.forEach((col, colIndex) => {
      const cell = row.getCell(colIndex + 1);
      const value = rowData[col.key];

      if (col.cellStyle) {
        cell.style = { ...cell.style, ...col.cellStyle };
      }

      if (col.getCellStyle) {
        const dynamicStyle = col.getCellStyle(value, rowIndex, rowData);
        cell.style = { ...cell.style, ...dynamicStyle };
      }

      const profileCellStyle = profile?.cellStyles?.[col.key];
      if (profileCellStyle) {
        cell.style = { ...cell.style, ...profileCellStyle };
      }
    });
  });

  if (sheetConfig.applySheetFormatting) {
    await sheetConfig.applySheetFormatting(sheet);
  }
}




import { Injectable } from '@nestjs/common';
import { Workbook } from 'exceljs';
import { ReportOptions, ReportFormat } from '../types/report.types';
import { generateExcelBuffer } from '../utils/excel.utils';
import { generateCsvBuffer } from '../utils/csv.utils';
import { generatePdfStream } from '../utils/pdf.utils';
import { writeReportToFile, generateFilename } from '../utils/file.utils';

@Injectable()
export class ReportService {
  async generateReport(options: ReportOptions): Promise<Buffer> {
    let buffer: Buffer;

    const firstSheet = options.sheets[0]; // Only first sheet for CSV/PDF

    switch (options.format) {
      case 'excel':
        buffer = await this.generateExcel(options);
        break;
      case 'csv':
        buffer = generateCsvBuffer(firstSheet);
        break;
      case 'pdf': {
        const { bufferPromise } = generatePdfStream(firstSheet);
        buffer = await bufferPromise;
        break;
      }
      default:
        throw new Error(`Unsupported format: ${options.format}`);
    }

    if (options.outputFilePath) {
      writeReportToFile(options.outputFilePath, buffer);
    }

    return buffer;
  }

  private async generateExcel(options: ReportOptions): Promise<Buffer> {
    const workbook = new Workbook();

    for (const sheetConfig of options.sheets) {
      const sheet = workbook.addWorksheet(sheetConfig.sheetName || 'Sheet');

      sheet.columns = sheetConfig.columns.map(col => ({
        header: col.header,
        key: col.key,
        width: col.width || 20,
      }));

      sheet.getRow(1).eachCell((cell, colNum) => {
        const col = sheetConfig.columns[colNum - 1];
        if (col?.headerStyle) {
          cell.style = col.headerStyle;
        }
      });

      sheetConfig.data.forEach((rowData, rowIndex) => {
        const row = sheet.addRow(rowData);

        if (sheetConfig.getRowStyle) {
          const style = sheetConfig.getRowStyle(rowData, rowIndex);
          row.eachCell(cell => cell.style = { ...cell.style, ...style });
        }

        sheetConfig.columns.forEach((col, colIndex) => {
          const cell = row.getCell(colIndex + 1);
          const value = rowData[col.key];

          if (col.cellStyle) {
            cell.style = { ...cell.style, ...col.cellStyle };
          }

          if (col.getCellStyle) {
            const dynamicStyle = col.getCellStyle(value, rowIndex, rowData);
            cell.style = { ...cell.style, ...dynamicStyle };
          }
        });
      });

      if (sheetConfig.applySheetFormatting) {
        await sheetConfig.applySheetFormatting(sheet);
      }
    }

    return generateExcelBuffer(workbook);
  }
}




import { Injectable } from '@nestjs/common';
import { Workbook } from 'exceljs';
import { ReportOptions, ReportColumn } from '../types/report.types';
import { generateExcelBuffer } from '../utils/excel.utils';

@Injectable()
export class ReportService {
  async generateReport(options: ReportOptions): Promise<Buffer> {
    const workbook = new Workbook();

    for (const sheetConfig of options.sheets) {
      const sheet = workbook.addWorksheet(sheetConfig.sheetName || 'Sheet');

      // Setup columns
      sheet.columns = sheetConfig.columns.map((col: ReportColumn) => ({
        header: col.header,
        key: col.key,
        width: col.width || 20,
      }));

      // Apply header style
      sheet.getRow(1).eachCell((cell, colNumber) => {
        const col = sheetConfig.columns[colNumber - 1];
        if (col?.headerStyle) {
          cell.style = col.headerStyle;
        }
      });

      // Add and style data rows
      sheetConfig.data.forEach((rowData, rowIndex) => {
        const row = sheet.addRow(rowData);

        // Apply row-level styling
        if (sheetConfig.getRowStyle) {
          const rowStyle = sheetConfig.getRowStyle(rowData, rowIndex);
          row.eachCell(cell => (cell.style = { ...cell.style, ...rowStyle }));
        }

        // Apply cell-level styles per column
        sheetConfig.columns.forEach((col, colIndex) => {
          const cell = row.getCell(colIndex + 1);
          const value = rowData[col.key];

          if (col.cellStyle) {
            cell.style = { ...cell.style, ...col.cellStyle };
          }

          if (col.getCellStyle) {
            const dynamicStyle = col.getCellStyle(value, rowIndex, rowData);
            cell.style = { ...cell.style, ...dynamicStyle };
          }
        });
      });

      // Optional custom formatting function
      if (sheetConfig.applySheetFormatting) {
        await sheetConfig.applySheetFormatting(sheet);
      }
    }

    return generateExcelBuffer(workbook);
  }
}
