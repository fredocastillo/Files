import { Injectable } from '@nestjs/common';
import { ReportFormat, ReportOptions } from '../types/report.types';
import { generateExcelReport } from '../utils/excel.utils';
import { generateCsvReport } from '../utils/csv.utils';
import { generatePdfReport } from '../utils/pdf.utils';

@Injectable()
export class ReportService {
  async generateReport(options: ReportOptions): Promise<Buffer> {
    switch (options.format) {
      case ReportFormat.EXCEL:
        return generateExcelReport(options);
      case ReportFormat.CSV:
        return generateCsvReport(options);
      case ReportFormat.PDF:
        return generatePdfReport(options);
      default:
        throw new Error('Unsupported format');
    }
  }
}