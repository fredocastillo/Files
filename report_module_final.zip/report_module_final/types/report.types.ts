export enum ReportFormat {
  EXCEL = 'excel',
  CSV = 'csv',
  PDF = 'pdf',
}

export interface ReportColumn {
  key: string;
  header: string;
}

export interface ReportSheet {
  sheetName: string;
  columns: ReportColumn[];
  data: Record<string, any>[];
  styleProfileKey?: string;
}

export interface ReportOptions {
  format: ReportFormat;
  sheets: ReportSheet[];
  outputFilePath?: string;
}

export interface StyleProfile {
  header?: any;
  row?: any;
  cell?: any;
}

import { Style } from 'exceljs';

export interface ReportStyleProfile {
  headerStyle?: Partial<Style>;
  rowStyle?: Partial<Style>;
  cellStyles?: Record<string, Partial<Style>>;
}

export interface ReportSheetOptions {
  sheetName: string;
  columns: ReportColumn[];
  data: ReportData[];
  styleProfileKey?: string; // <-- new
  applySheetFormatting?: (sheet: Worksheet) => Promise<void> | void;
  getRowStyle?: (rowData: ReportData, rowIndex: number) => Partial<Style>;
}


import { Worksheet, Style } from 'exceljs';

export type ReportFormat = 'excel' | 'csv' | 'pdf';

export interface ReportColumn {
  key: string;
  header: string;
  width?: number;
  headerStyle?: Partial<Style>;
  cellStyle?: Partial<Style>;
  getCellStyle?: (value: any, rowIndex: number, rowData: ReportData) => Partial<Style>;
}

export type ReportData = Record<string, any>;

export interface ReportSheetOptions {
  sheetName: string;
  columns: ReportColumn[];
  data: ReportData[];
  applySheetFormatting?: (sheet: Worksheet) => Promise<void> | void;
  getRowStyle?: (rowData: ReportData, rowIndex: number) => Partial<Style>;
}

export interface ReportOptions {
  format: ReportFormat;
  sheets: ReportSheetOptions[];
  outputFilePath?: string; // optional for writing to file
}



import { Worksheet, Style } from 'exceljs';

export interface ReportColumn {
  key: string;
  header: string;
  width?: number;
  headerStyle?: Partial<Style>;
  cellStyle?: Partial<Style>;
  getCellStyle?: (value: any, rowIndex: number, rowData: ReportData) => Partial<Style>; // Optional dynamic styling
}

export type ReportData = Record<string, any>;

export interface ReportSheetOptions {
  sheetName: string;
  columns: ReportColumn[];
  data: ReportData[];
  applySheetFormatting?: (sheet: Worksheet) => Promise<void> | void;
  getRowStyle?: (rowData: ReportData, rowIndex: number) => Partial<Style>;
}

export interface ReportOptions {
  sheets: ReportSheetOptions[];
}
