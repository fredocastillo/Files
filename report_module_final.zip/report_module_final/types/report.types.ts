export enum ReportFormat {
  EXCEL = 'excel',
  CSV = 'csv',
  PDF = 'pdf',
}

export interface ReportColumn {
  key: string;
  header: string;
}

export interface ReportSheet {
  sheetName: string;
  columns: ReportColumn[];
  data: Record<string, any>[];
  styleProfileKey?: string;
}

export interface ReportOptions {
  format: ReportFormat;
  sheets: ReportSheet[];
  outputFilePath?: string;
}

export interface StyleProfile {
  header?: any;
  row?: any;
  cell?: any;
}