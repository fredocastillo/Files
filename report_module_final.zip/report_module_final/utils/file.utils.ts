import * as fs from 'fs';
import * as path from 'path';

export function writeToFile(buffer: Buffer, filePath: string): void {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(filePath, buffer);
}