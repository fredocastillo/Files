import * as fs from 'fs';
import * as path from 'path';

export function writeToFile(buffer: Buffer, filePath: string): void {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(filePath, buffer);
}



import { writeFileSync } from 'fs';
import { join } from 'path';

export function writeReportToFile(filePath: string, buffer: Buffer): void {
  writeFileSync(filePath, buffer);
}

export function generateFilename(baseName: string, extension: string): string {
  return join(process.cwd(), `${baseName}.${extension}`);
}
