import { ReportOptions } from '../types/report.types';
import { format } from '@fast-csv/format';
import { Writable } from 'stream';

export async function generateCsvReport(options: ReportOptions): Promise<Buffer> {
  const sheet = options.sheets[0];
  const stream = format({ headers: sheet.columns.map(col => col.header) });
  const chunks: Buffer[] = [];

  const writable = new Writable({
    write(chunk, _, callback) {
      chunks.push(Buffer.from(chunk));
      callback();
    }
  });

  stream.pipe(writable);
  sheet.data.forEach(row => {
    stream.write(sheet.columns.map(col => row[col.key]));
  });
  stream.end();

  return new Promise((resolve) => {
    writable.on('finish', () => {
      resolve(Buffer.concat(chunks));
    });
  });
}



import { stringify } from 'csv-stringify/sync';
import { ReportSheetOptions } from '../types/report.types';

export function generateCsvBuffer(sheet: ReportSheetOptions): Buffer {
  const records = [sheet.columns.map(c => c.header)];

  for (const row of sheet.data) {
    records.push(sheet.columns.map(c => row[c.key]));
  }

  const csv = stringify(records, { header: false });
  return Buffer.from(csv);
}
