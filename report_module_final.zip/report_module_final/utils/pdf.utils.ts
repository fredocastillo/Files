import PDFDocument from 'pdfkit';
import { ReportOptions } from '../types/report.types';

export async function generatePdfReport(options: ReportOptions): Promise<Buffer> {
  const doc = new PDFDocument();
  const buffers: Buffer[] = [];

  doc.on('data', chunk => buffers.push(chunk));
  doc.on('end', () => {});

  const sheet = options.sheets[0];

  doc.fontSize(14).text(sheet.sheetName, { underline: true });
  doc.moveDown();

  const headers = sheet.columns.map(col => col.header).join(' | ');
  doc.font('Helvetica-Bold').text(headers);
  sheet.data.forEach(row => {
    const values = sheet.columns.map(col => row[col.key]).join(' | ');
    doc.font('Helvetica').text(values);
  });

  doc.end();

  return new Promise(resolve => {
    doc.on('end', () => resolve(Buffer.concat(buffers)));
  });
}