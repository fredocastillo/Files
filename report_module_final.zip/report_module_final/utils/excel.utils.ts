import ExcelJS from 'exceljs';
import { ReportOptions } from '../types/report.types';
import { styleProfiles } from '../styles/style-profiles';

export async function generateExcelReport(options: ReportOptions): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();

  for (const sheetOpt of options.sheets) {
    const sheet = workbook.addWorksheet(sheetOpt.sheetName);
    const profile = styleProfiles[sheetOpt.styleProfileKey || 'default'];

    sheet.columns = sheetOpt.columns.map(col => ({ header: col.header, key: col.key }));

    sheetOpt.data.forEach(data => {
      sheet.addRow(data);
    });

    if (profile?.header) {
      sheet.getRow(1).eachCell(cell => Object.assign(cell, profile.header));
    }

    if (profile?.row || profile?.cell) {
      sheet.eachRow((row, rowNum) => {
        if (rowNum > 1) {
          row.eachCell(cell => {
            if (profile.row) Object.assign(cell, profile.row);
            if (profile.cell) Object.assign(cell, profile.cell);
          });
        }
      });
    }
  }

  return workbook.xlsx.writeBuffer();
}