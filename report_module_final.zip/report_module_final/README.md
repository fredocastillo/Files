# Report Module (NestJS)

This module supports generating reports in Excel, CSV, and PDF with multi-sheet capabilities and style profiles.

## Usage

Inject `ReportService` and call `generateReport()` with the desired options.

## Formats

- Excel (multi-sheet, styled)
- CSV
- PDF

## Style Profiles

Customize the appearance via `styleProfiles` (header, cell, row level).

## Folder Structure

- `services/` - Core report generation logic
- `utils/` - Format-specific generators and file helpers
- `styles/` - Centralized reusable styling profiles
- `types/` - TypeScript interfaces and enums

---


```
npm install exceljs csv-stringify pdfkit
npm install --save-dev @types/pdfkit

```


```
await this.reportService.generateReport({
  format: 'excel',
  outputFilePath: 'finance-report.xlsx',
  sheets: [
    {
      sheetName: 'Summary',
      styleProfileKey: 'finance',
      columns: [
        { key: 'category', header: 'Category' },
        { key: 'amount', header: 'Amount' },
        { key: 'percentage', header: 'Contribution' },
      ],
      data: [
        { category: 'Product A', amount: 12000, percentage: 0.3 },
        { category: 'Product B', amount: 28000, percentage: 0.7 },
      ],
    }
  ]
});

```

```
const options: ReportOptions = {
  sheets: [
    {
      sheetName: 'Users',
      columns: [
        {
          key: 'id',
          header: 'ID',
          width: 10,
          headerStyle: { bold: true, font: { color: { argb: 'FFFFFFFF' } }, fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF000000' } } },
          cellStyle: { alignment: { horizontal: 'center' } }
        },
        {
          key: 'name',
          header: 'Name',
          headerStyle: { bold: true },
          getCellStyle: (val) => ({ font: { italic: true }, alignment: { horizontal: 'left' } })
        },
      ],
      data: [
        { id: 1, name: 'Alice' },
        { id: 2, name: 'Bob' },
      ],
      getRowStyle: (row, index) => {
        return index % 2 === 0 ? { fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF0F0F0' } } } : {};
      }
    },
    {
      sheetName: 'Summary',
      columns: [
        { key: 'metric', header: 'Metric', headerStyle: { bold: true } },
        { key: 'value', header: 'Value', headerStyle: { bold: true } },
      ],
      data: [
        { metric: 'Total Users', value: 2 },
      ],
    }
  ]
};

const buffer = await reportService.generateReport(options);

```