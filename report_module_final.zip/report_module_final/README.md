# Report Module (NestJS)

This module supports generating reports in Excel, CSV, and PDF with multi-sheet capabilities and style profiles.

## Usage

Inject `ReportService` and call `generateReport()` with the desired options.

## Formats

- Excel (multi-sheet, styled)
- CSV
- PDF

## Style Profiles

Customize the appearance via `styleProfiles` (header, cell, row level).

## Folder Structure

- `services/` - Core report generation logic
- `utils/` - Format-specific generators and file helpers
- `styles/` - Centralized reusable styling profiles
- `types/` - TypeScript interfaces and enums

---