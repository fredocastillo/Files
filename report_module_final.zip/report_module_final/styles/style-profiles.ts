import { Partial } from 'exceljs';
import { ReportStyleProfile } from '../types/report.types';

export const ReportStyleProfiles: Record<string, ReportStyleProfile> = {
  'default': {
    headerStyle: {
      font: { bold: true, color: { argb: 'FFFFFFFF' } },
      fill: {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FF333399' },
      },
      alignment: { horizontal: 'center' },
    },
    rowStyle: {
      font: { name: 'Arial', size: 11 },
    },
    cellStyles: {},
  },

  'finance': {
    headerStyle: {
      font: { bold: true, color: { argb: 'FFFFFFFF' } },
      fill: {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FF2E8B57' },
      },
    },
    rowStyle: {},
    cellStyles: {
      amount: {
        numFmt: '"$"#,##0.00;[Red]\-"$"#,##0.00',
      },
      percentage: {
        numFmt: '0.00%',
      },
    },
  },
};
