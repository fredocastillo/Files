import { StyleProfile } from '../types/report.types';
import { defaultProfile } from './default.profile';

export const styleProfiles: Record<string, StyleProfile> = {
  default: defaultProfile,
};