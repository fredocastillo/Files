import { StyleProfile } from '../types/report.types';

export const defaultProfile: StyleProfile = {
  header: { font: { bold: true }, alignment: { horizontal: 'center' } },
  row: { font: { size: 12 } },
  cell: { border: { top: {}, bottom: {}, left: {}, right: {} } },
};