
# Report Module (NestJS)

This module provides a flexible and reusable system for generating reports in various formats including Excel, CSV, and PDF. It supports advanced styling, templating, multi-sheet output, and includes a CLI tool for managing templates and previewing reports.

---

## Features

- Excel, CSV, and PDF generation
- Support for multiple sheets
- Stream or save to disk
- Style profiles for consistent formatting
- CLI tool for listing, previewing, and scaffolding profiles
- Reusable decorators, utils, and types

---

## Folder Structure

- `decorators/` – Optional custom decorators for reports
- `services/` – Main service logic for report generation
- `styles/` – Style profiles (imported into a single registry)
- `tools/` – CLI tool (`report-cli.ts`)
- `types/` – Type definitions for reports, formats, styling
- `utils/` – Helpers for working with Excel, CSV, PDF, and file output

---

## CLI Usage

Run from your project root:

```bash
npm run report:cli list-profiles

npm run report:cli preview -p default -f excel -o output/sample-report

npm run report:cli create-profile myCustomProfile
```

---

## Integration

1. Place the module in your `libs/` folder.
2. Register `ReportService` in your NestJS provider module.
3. Use the service in any application-level service/controller to generate reports.
4. Define and extend `style-profiles.ts` with your own profiles as needed.

---

## Example Usage (Service)

```ts
await this.reportService.generateReport({
  format: 'excel',
  outputFilePath: 'reports/monthly.xlsx',
  sheets: [{
    sheetName: 'Summary',
    styleProfileKey: 'default',
    columns: [
      { key: 'name', header: 'Employee Name' },
      { key: 'salary', header: 'Monthly Salary' },
    ],
    data: employees,
  }]
});
```

---
